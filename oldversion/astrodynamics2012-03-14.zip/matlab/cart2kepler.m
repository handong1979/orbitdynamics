%��������ת��Ϊ������� cart2kepler(cart,miu)
% use:
%    cart2kepler(cart); %Ĭ��Ϊ����
%    cart2kepler(cart,miu);  %������������
%    ����cart����Ϊ1*6(��λkm,km/s)
%    ����ʱmiuΪ398600.5km^3/s^2������ʱmiuΪ4902.8km^3/s^2
% result:
%    kepler = [a  e  i Omega  w  M](��λ:km  rad)
function kepler = cart2kepler(cart,miu)

if all(size(cart)~=[6,1]) && all(size(cart)~=[1,6])
    error('cart2kepler: input cart must dimension error');
end
if nargin == 1
    miu = 398600.4416;
end

P = [cart(1);cart(2);cart(3)];
V = [cart(4);cart(5);cart(6)];
r = norm(P);
v = norm(V);
v2 = v*v;
% rrd = P'*V;

% a
kepler(1) = 1.0 / (2.0/r - v2/miu);
Uz = [0;0;1];
h = cross(P,V);
N = cross(Uz,h);
p = h'*h/miu;

% e
if p/kepler(1)>1.0
    kepler(2) = 0;
else
    kepler(2) = sqrt(1.0 - p/kepler(1));
end

% i
cosi = h'*Uz/norm(h);
if cosi >= 1.0
    kepler(3) = 0.0;
elseif cosi <= -1.0
    kepler(3) = pi;
else
    kepler(3) = acos(cosi);
end

% Omega
Nx = N(1)/norm(N);
if Nx >= 1.0
    kepler(4) = 0.0;
elseif Nx <= -1.0
    kepler(4) = pi;
else
    if N(2)>0
        kepler(4) = acos(Nx);
    else
        kepler(4) = pi*2 - acos(Nx);
    end
end

% w
E = cross(V,h)/miu - P/r;
cosw = N'*E/norm(N)/norm(E);
if cosw >= 1.0
    kepler(5) = 0.0;
elseif cosw <= -1.0
    kepler(5) = pi;
else
    if E(3)>0
        kepler(5) = acos(cosw);
    else
        kepler(5) = pi*2 - acos(cosw);
    end
end

% M
cosu = P'*N/r/norm(N);
if cosu >= 1.0
    u = 0.0;
elseif cosu <= -1.0
    u = pi;
else
    if P(3)>0
        u = acos(cosu);
    else
        u = pi*2 - acos(cosu);
    end
end
if kepler(2)>1
    x = ((kepler(2)-1)/(1+kepler(2)))^0.5 * tan((u-kepler(5))/2.0);
    EE = log((1+x)/(1-x));
    kepler(6) = kepler(2)*sinh(EE) - EE;
else
    EE = mod(2.0 * atan( ((1-kepler(2))/(1+kepler(2)))^0.5 * tan((u-kepler(5))/2.0) ) + pi*2,pi*2);
    kepler(6) = EE - kepler(2)*sin(EE);
end
