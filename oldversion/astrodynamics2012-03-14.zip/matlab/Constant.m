% ���ó��õĳ���ֵ��ȫ������Const�ṹ��
Const.RAD=0.017453292519943295769236907684886;   %degree to radian
Const.DEG=57.295779513082320876798154814105;     %radian to degree
Const.GE=398600.4415;     %geocentric gravitational constant (km^3/s^2)
Const.Re=6378.137;	    %earth equatorial mean radius(km)
Const.Oblate=0.003352813; %earth oblate
Const.We=7.2921159e-5;    %earth ratation rate
Const.G=6.672e-20;        %gravitational constant(Km^3/Kg/s^2)
Const.GM=4902.802627;     %selenocentric gravitational constant (km^3/s^2)
Const.GS=1.32712438e+11;  %heliocentric gravitational constant (km^3/s^2)
Const.TU=806.81112412790870095017550956071;  %time unit(��s)
Const.VU=7.905365716039427018020816039069;   %velocity unit(��km/s)
