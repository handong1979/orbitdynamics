%�⿪���շ��� M = E - e*sin(E)
function E = keplerfunc(e,M)
error(nargchk(2,2,nargin));
if e<0 || e>1
    error('keplerfunc(e=%f,m=%f) is failed\n',e,M);
end
E0 = M;
if e<1.0
    E1 = E0-(E0-e*sin(E0)-M)/(1-e*cos(E0));
else
    E1 = E0-(e*sinh(E0)-E0-M)/(e*cosh(E0)-1.0);
end

while abs(E1-E0)>1e-12
    E0 = E1;
%     n = n+1;
    if e<1.0
        E1 = E0-(E0-e*sin(E0)-M)/(1-e*cos(E0));
    else
        E1 = E0-(e*sinh(E0)-E0-M)/(e*cosh(E0)-1.0);
    end
end
E = E1;