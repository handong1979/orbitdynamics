% ����ֱ������ƽ�����ͼ
% phaseplane(thetaD,thetaB,Kj1,Kj2,dthetal,dthetall,dthetav,dthetaS,range)
%   ������ƽ����������Ƴ���ƽ�������߼�����ͼ
% Example:
%     phaseplane(1,3,1,2,0.3,0.9,0.1,0.4,[-9 9 -1.1 1.1]);
function ax = phaseplane(thetaD,thetaB,Kj1,Kj2,dthetal,dthetall,dthetav,dthetaS,range)
if nargin == 8
	xmin = -20;
    xmax = 20;
    ymin = -2;
    ymax = 2;
elseif nargin == 9
   	xmin = range(1);
    xmax = range(2);
    ymin = range(3);
    ymax = range(4); 
else
    error('���������������ȷ');
end

figure,
set(gcf,'Position',[160   160   960   760]);
ax = axes;
set(ax,'XLim',[xmin xmax]);
set(ax,'YLim',[ymin ymax]);
hold on;
% line axe
line([xmin xmax],[0 0],'linewidth',2);
line([0 0],[ymin ymax],'linewidth',2);

% line GCD
line([xmin thetaD],[(thetaD-xmin)/Kj1 0],'linewidth',2);
line(-[xmin thetaD],-[(thetaD-xmin)/Kj1 0],'linewidth',2);
% line CA
line([thetaD-dthetaS*Kj1 xmax],[dthetaS dthetaS],'linewidth',2);
line(-[thetaD-dthetaS*Kj1 xmax],-[dthetaS dthetaS],'linewidth',2);
% dot line CA
line([thetaD-dthetaS*Kj1 0],[dthetaS dthetaS],'linewidth',2,'linestyle',':');
line(-[thetaD-dthetaS*Kj1 0],-[dthetaS dthetaS],'linewidth',2,'linestyle',':');
% line HM
line([thetaD-dthetav*Kj1 thetaB-dthetav*Kj2],[dthetav dthetav],'linewidth',2);
line(-[thetaD-dthetav*Kj1 thetaB-dthetav*Kj2],-[dthetav dthetav],'linewidth',2);
% dot line HM
line([thetaD-dthetav*Kj1 0],[dthetav dthetav],'linewidth',2,'linestyle',':');
line(-[thetaD-dthetav*Kj1 0],-[dthetav dthetav],'linewidth',2,'linestyle',':');
% line AMB-
line([thetaB-dthetaS*Kj2 thetaB+dthetal*Kj2],[dthetaS -dthetal],'linewidth',2);
line(-[thetaB-dthetaS*Kj2 thetaB+dthetal*Kj2],-[dthetaS -dthetal],'linewidth',2);
% line DE
line([thetaD thetaD],[0 -dthetal],'linewidth',2);
line(-[thetaD thetaD],-[0 -dthetal],'linewidth',2);
% line EF
line([thetaD xmax],[-dthetal -dthetal],'linewidth',2);
line(-[thetaD xmax],-[-dthetal -dthetal],'linewidth',2);
% dot line EF
line([thetaD 0],[-dthetal -dthetal],'linewidth',2,'linestyle',':');
line(-[thetaD 0],-[-dthetal -dthetal],'linewidth',2,'linestyle',':');
% line IJ..
line([thetaB-ymin*Kj2 thetaB+dthetall*Kj2 xmax],[ymin -dthetall -dthetall],'linewidth',2);
line(-[thetaB+ymax*Kj2 thetaB+dthetall*Kj2 xmax],-[ymin -dthetall -dthetall],'linewidth',2);
% dot line IJ
line([thetaB+dthetall*Kj2 0],[-dthetall -dthetall],'linewidth',2,'linestyle',':');
line(-[thetaB+dthetall*Kj2 0],-[-dthetall -dthetall],'linewidth',2,'linestyle',':');


% text
text(thetaD,0,'\theta_D','VerticalAlignment','Top');
text(thetaB,0,'\theta_B','VerticalAlignment','bottom');
text(-thetaD,0,'-\theta_D','VerticalAlignment','Top');
text(-thetaB,0,'-\theta_B','VerticalAlignment','bottom');
text('Position',[0,dthetav],'Interpreter','latex','String','$$\dot\theta _V$$','fontsize',12,'HorizontalAlignment','right');
text('Position',[0,dthetaS],'Interpreter','latex','String','$$\dot\theta _S$$','fontsize',12,'HorizontalAlignment','right');
text('Position',[0,-dthetav],'Interpreter','latex','String','$$\dot\theta _V$$','fontsize',12,'HorizontalAlignment','left');
text('Position',[0,-dthetaS],'Interpreter','latex','String','$$\dot\theta _S$$','fontsize',12,'HorizontalAlignment','left');
text('Position',[0,-dthetal],'Interpreter','latex','String','$$-\dot\theta _l$$','fontsize',12,'HorizontalAlignment','right');
text('Position',[0,-dthetall],'Interpreter','latex','String','$$-\dot\theta _{ll}$$','fontsize',12,'HorizontalAlignment','right');
text('Position',[0,dthetal],'Interpreter','latex','String','$$-\dot\theta _l$$','fontsize',12,'HorizontalAlignment','left');
text('Position',[0,dthetall],'Interpreter','latex','String','$$-\dot\theta _{ll}$$','fontsize',12,'HorizontalAlignment','left');

text(0,0,'O','VerticalAlignment','Top');

text(thetaB,dthetaS+0.1,'R11');
text((thetaB+thetaD)/2,(dthetav+dthetaS)/2,'R12','HorizontalAlignment','center');
text((thetaB+thetaD)/2,dthetav/2,'R13','HorizontalAlignment','center');
text((thetaB+thetaD)/2,-dthetal/2,'R14','HorizontalAlignment','center');
text((thetaB+xmax)/2,dthetaS/2,'R15');
text((thetaB+xmax)/2,-dthetal/2,'R16');
text(thetaB+dthetall*Kj2+1,-dthetall,'R17','VerticalAlignment','Top');

text(-thetaB,-dthetaS-0.1,'R21');
text(-(thetaB+thetaD)/2,-(dthetav+dthetaS)/2,'R22','HorizontalAlignment','center');
text(-(thetaB+thetaD)/2,-dthetav/2,'R23','HorizontalAlignment','center');
text(-(thetaB+thetaD)/2,dthetal/2,'R24','HorizontalAlignment','center');
text(-(thetaB+xmax)/2,-dthetaS/2,'R25');
text(-(thetaB+xmax)/2,dthetal/2,'R26');
text(-(thetaB+dthetall*Kj2)-1,dthetall,'R27','VerticalAlignment','bottom','HorizontalAlignment','right');
