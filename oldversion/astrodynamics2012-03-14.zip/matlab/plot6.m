% ����3��2������subplot����
% plot a 3*2 subplot in current figure
% plot6(x)
% subplot is column order with x
function plot6(x,varargin)
if nargin == 0, error('Not enough input arguments.'); end
if size(x,2) == 6
    t = 1:length(x);
    y = x;
elseif size(x,2) == 7
    t = x(:,1);
    y = x(:,2:end);
end

labeled = false;

if nargin==1
    hasoption = false;
else
    if strcmpi(varargin{1},'LABEL') && nargin > 7
        labeled = true;
        str1 = varargin{2};
        str2 = varargin{3};
        str3 = varargin{4};
        str4 = varargin{5};
        str5 = varargin{6};
        str6 = varargin{7};
        if nargin > 8
            option = varargin{8:end};
            hasoption = true;
        else
            hasoption = false;
        end
    else
        option = varargin{:};
        hasoption = true;
    end
end
if hasoption
    subplot(3,2,1),plot(t,y(:,1),option),grid on,hold on;
    subplot(3,2,3),plot(t,y(:,2),option),grid on,hold on;
    subplot(3,2,5),plot(t,y(:,3),option),grid on,hold on;
    subplot(3,2,2),plot(t,y(:,4),option),grid on,hold on;
    subplot(3,2,4),plot(t,y(:,5),option),grid on,hold on;
    subplot(3,2,6),plot(t,y(:,6),option),grid on,hold on;
else
    subplot(3,2,1),plot(t,y(:,1)),grid on,hold on;
    subplot(3,2,3),plot(t,y(:,2)),grid on,hold on;
    subplot(3,2,5),plot(t,y(:,3)),grid on,hold on;
    subplot(3,2,2),plot(t,y(:,4)),grid on,hold on;
    subplot(3,2,4),plot(t,y(:,5)),grid on,hold on;
    subplot(3,2,6),plot(t,y(:,6)),grid on,hold on;
end

if labeled == true
  subplot(3,2,1),ylabel(str1);
  subplot(3,2,3),ylabel(str2);
  subplot(3,2,5),ylabel(str3);
  subplot(3,2,2),ylabel(str4);
  subplot(3,2,4),ylabel(str5);
  subplot(3,2,6),ylabel(str6);
end

