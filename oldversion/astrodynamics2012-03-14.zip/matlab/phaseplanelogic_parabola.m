% ����������ƽ�����������߼�
% �ṹppp�а�����
%   thetaD   thetaB  thetaV  Dtheta
%   dthetaL  dthetaS  dthetaV  dthetaLL
%   Kx  aJS  aJL Mpsi
function [FJB TN region thetapst] = phaseplanelogic_parabola(theta,dtheta,thetapst,ppp)

if theta >= 0
    sign = 1;
else
    sign = -1;
end

thetac = theta*sign;
dthetac = dtheta*sign;

if (thetac - ppp.thetaD + dthetac^2/2/ppp.ajl/ppp.Kx >= 0) && (dthetac - ppp.dthetaS >=0)
    region = 'R11';
    FJB = 10;
    TN = ppp.TMAX;
    thetapst = thetac + ppp.thetaV;
elseif (thetac + ppp.thetaD + dthetac^2/2/ppp.ajl/ppp.Kx < 0) && dtheta<0
    region = 'R21';
    FJB = 10;
    TN = -ppp.TMAX;
    thetapst = thetac + ppp.thetaV;
elseif (thetac - ppp.thetaD + dthetac^2/2/ppp.ajl/ppp.Kx >= 0) && (dthetac - ppp.dthetaS < 0) ...
       && (dthetac - ppp.thetaV >= 0) && (thetac - ppp.thetaB < 0)
    region = 'R12';
    FJB = 5;
    TN = ppp.TMAX;
    thetapst = thetac + ppp.thetaV;
elseif (thetac - ppp.thetaD + dthetac^2/2/ppp.ajl/ppp.Kx >= 0) && (dthetac - ppp.dthetaV < 0) ...
        && dthetac >= 0 && (thetac - ppp.thetaB < 0)
    region = 'R13';
    if thetac - thetapst >=0
        FJB = 5;
        thetapst = thetac + ppp.thetaV;
        if ppp.Mpsi == 1
            TN = ppp.TMIN;
        else
            TN1 = dthetac/ppp.ajs;
            TN2 = ppp.Kj*(thetac-ppp.Dtheta)/ppp.ajs;
            if TN2 > 0.5*ppp.TMAX
            	TN2 = 0.5*ppp.TMAX;
            end
            TN = TN1+TN2;
            if TN < ppp.TMIN
                TN = ppp.TMIN;
            end
        end
    else
        FJB = 0;
        TN = 0;
        if thetac - thetapst + ppp.thetaV < 0
            thetapst = thetac + ppp.thetaV;
        end
    end
elseif thetac-ppp.thetaD >= 0 && dthetac < 0 && ...
        (dthetac + ppp.dthetaL >=0) && (thetac - ppp.thetaB - dthetac^2/2/ppp.ajl/ppp.Kx < 0)
    region = 'R14';
    if thetac - thetapst >= 0
        FJB = 5;
        TN = ppp.TMIN;
        thetapst = thetac + ppp.thetaV;
    else
        FJB = 0;
        TN = 0;
        if thetac - thetapst + ppp.thetaV < 0
            thetapst = thetac + ppp.thetaV;
        end
    end
elseif (dthetac - ppp.dthetaS < 0) && dthetac >=0 && (thetac - ppp.thetaB >= 0)
    region = 'R15';
    FJB = 10;
    TN = (dthetac + ppp.dthetaL)/ppp.ajl + ppp.TMIN;
    thetapst = thetac + ppp.thetaV;
elseif dthetac < 0 && (dthetac + ppp.dthetaL >= 0) && (thetac - ppp.thetaB - dthetac^2/2/ppp.ajl/ppp.Kx >= 0)
    region = 'R16';
    FJB = 10;
    TN = (dthetac + ppp.dthetaL)/ppp.ajl + ppp.TMIN;
    thetapst = thetac + ppp.thetaV;
elseif dthetac + ppp.dthetaLL < 0 && (thetac - ppp.thetaB - dthetac^2/2/ppp.ajl/ppp.Kx >= 0)
    region = 'R17';
    FJB = 10;
    TN = -ppp.TMAX;
    thetapst = thetac + ppp.thetaV;
else
   region = 'R0';
   FJB = 0;
   TN = 0;
   thetapst = thetac - ppp.thetaV;
end

if TN >= ppp.TMAX
    TN  = ppp.TMAX;
elseif TN <= -ppp.TMAX
    TN = - ppp.TMAX;
end

if sign > 0
    TN = -TN;
end
