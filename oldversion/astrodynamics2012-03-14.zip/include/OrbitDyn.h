#ifndef __ORBITDYN_H
#define __ORBITDYN_H


#include "DE405.h"
#include "Facility.h"
#include "Satellite.h"
#include "utility.h"

#define TAB "\t"


#ifdef ORBITDYN_STATIC
//#ifndef ORBITDYN_DLL

// VC2005
#if _MSC_VER >= 1400
	#ifdef _MT
		#ifdef _DLL
			#ifdef _DEBUG
				#pragma comment(lib,"OrbitDynMDllD.lib")
			#else
				#pragma comment(lib,"OrbitDynMDLLR.lib")
			#endif //_DEBUG
		#else //_DLL
			#ifdef _DEBUG
				#pragma comment(lib,"OrbitDynMD.lib")
			#else
				#pragma comment(lib,"OrbitDynMR.lib")
			#endif //_DEBUG
		#endif //_DLL
	#else
		#error û�ж���_MT,�޷�ȷ��ʹ�õĿ��ļ�
	#endif //_MT
#else
//#error ��֧��VC2005���°汾��VC
	#ifdef _DEBUG
		#pragma comment(lib,"OrbitDynSD.lib")
	#else
		#pragma comment(lib,"OrbitDynSR.lib")
	#endif //_DEBUG
#endif // _MSC_VER

#else

	#ifndef ORBITDYN_EXPORTS
		#ifdef _DEBUG
			#ifdef NONE_DATA_FILE_MODE
				#pragma comment(lib,"OrbitDynNFD.lib")
			#else
				#pragma comment(lib,"OrbitDynD.lib")
			#endif //NONE_DATA_FILE_MODE
		#else
			#ifdef NONE_DATA_FILE_MODE
				#pragma comment(lib,"OrbitDynNF.lib")
			#else
				#pragma comment(lib,"OrbitDyn.lib")
			#endif //NONE_DATA_FILE_MODE
#endif // _DEBUG
	#endif

#endif // ORBITDYN_DLL


#endif // __ORBITDYN_H
