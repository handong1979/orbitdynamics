#ifndef __QUATERNION_H
#define __QUATERNION_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#if defined _MSC_VER && _MSC_VER < 1300
	#include <iostream.h>
	#include <fstream.h>
	#include <math.h>
	#include <stdexcpt.h>
#else
	#include <iostream>
	#include <cmath>
	#include <stdexcept>
	using namespace std;
#endif // _MSC_VER

#include "config.h"
#include "Vector.h"
#include "matrixTCL.h"

/*!��Ԫ��
*/
class ORBITDYN_API CQuaternion
{
public:
	double qx,qy,qz,qs;

	/*!Ĭ�Ϲ��캯��*/
	CQuaternion():qx(0),qy(0),qz(0),qs(1){ }

	/*!���캯��*/
	CQuaternion(double x,double y,double z,double s):qx(x),qy(y),qz(z),qs(s){ }
	
	/*!��ת�ᡢת�ǹ���*/
	CQuaternion(const Vector& e,double phi);
	
	/*!�÷�����������*/
	CQuaternion(Matrix& c);

	/*!��������*/
	~CQuaternion(){}

	/*!��Ԫ���ķ���*/
	double Norm()const;

	/*!��Ԫ���淶��*/
	void Normalize();
	
	/*!��һ��ת���µ�ŷ����*/
	void EulerAngles(char* seq,double& phi,double& theta,double& ksi) const;
	
	/*!��Ԫ����Ӧ�ķ���������*/
	Matrix C() const;

	/*!ʸ������*/
	Vector v() const;
};

ORBITDYN_API const CQuaternion operator-(const CQuaternion &q);
ORBITDYN_API const CQuaternion operator*(const CQuaternion& q1,const CQuaternion& q2);
ORBITDYN_API const CQuaternion operator/(const CQuaternion& q2,const CQuaternion& q1);
ORBITDYN_API const CQuaternion Qm(const CQuaternion& q1,const CQuaternion& q2);
ORBITDYN_API const CQuaternion Qim(const CQuaternion& q1,const CQuaternion& q2);
ORBITDYN_API const Vector operator*(const CQuaternion& q,const Vector& v);
ORBITDYN_API ostream & operator<<(ostream & os, const CQuaternion& q);
ORBITDYN_API istream & operator>>(istream & is, CQuaternion& q);

class ORBITDYN_API CQuaternionException : public BaseException
{
public:
	CQuaternionException(const std::string& details = "") 
		: BaseException("CEuler exception:",details)
	{
	}
	virtual ~CQuaternionException()
	{
	}
	CQuaternionException(const CQuaternionException& cdte)
		:BaseException(cdte)
	{
	}
};

#endif // __QUATERNION_H
