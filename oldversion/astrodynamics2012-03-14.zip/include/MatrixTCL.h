////////////////////////////////////////////////
//��������
//�������ڣ�2004-9-1
//�����ˣ�����
//�������ݣ�
//   ԭ���뺬�д����ĺ궨�壬����ʹ�ø��ֱ�������ϵͳ������
//���������ʹ���ϵ��鷳��Ϊ�˷���ʹ�ã�������ȫ��ɾ����Ŀ
//ǰ�汾�ʺ�MS VC++6.0�����ϰ汾�ı�����

//����Ϊԭ����Ϣ��
////////////////////////////////
// Matrix TCL Lite v1.13
// Copyright (c) 1997-2002 Techsoft Pvt. Ltd. (See License.Txt file.)
//
// MatrixTCL.h: Matrix C++ template class include file
// Web: http://www.techsoftpl.com/matrix/
// Email: matrix@techsoftpl.com
//

//////////////////////////////
// Note: This matrix template class defines majority of the matrix
// operations as overloaded operators or methods. It is assumed that
// users of this class is familiar with matrix algebra. We have not
// defined any specialization of this template here, so all the instances
// of matrix will be created implicitly by the compiler. The data types
// tested with this class are float, double, long double, complex<float>,
// complex<double> and complex<long double>. Note that this class is not
// optimized for performance.
//
//  Since all the definitions are also included in this header file as
//  inline function, some compiler may give warning "inline function
//  can't be expanded". You may ignore/disable this warning using compiler
//  switches. All the operators/methods defined in this class have their
//  natural meaning except the followings:
//
//  Operator/Method                          Description
//  ---------------                          -----------
//   operator ()   :   This function operator can be used as a
//                     two-dimensional subscript operator to get/set
//                     individual matrix elements.
//
//   operator !    :   This operator has been used to calculate inversion
//                     of matrix.
//
//   operator ~    :   This operator has been used to return transpose of
//                     a matrix.
//
//   operator ^    :   It is used calculate power (by a scalar) of a matrix.
//                     When using this operator in a matrix equation, care
//                     must be taken by parenthesizing it because it has
//                     lower precedence than addition, subtraction,
//                     multiplication and division operators.
//
//   operator >>   :   It is used to read matrix from input stream as per
//                     standard C++ stream operators.
//
//   operator <<   :   It is used to write matrix to output stream as per
//                     standard C++ stream operators.
//
// Note that professional version of this package, Matrix TCL Pro 2.11
// is optimized for performance and supports many more matrix operations.
// It is available from our web site at <http://www.techsoftpl.com/matrix/>.
//        ��ϧ������ѵ�:(  ��~~~

#ifndef __cplusplus
#error Must use C++ for the type matrix.
#endif

#ifndef __STD_MATRIX_H
#define __STD_MATRIX_H

#include "config.h"
#include "BaseException.h"

#if defined _MSC_VER && _MSC_VER < 1300
	#include <stdio.h>
	#include <stdlib.h>
	#include <math.h>
	#include <iostream.h>
	#include <string.h>	
#else
	//#pragma warning(disable : 4290)
	#include <cmath>
	#include <iostream>
	using namespace std;
#endif

#if defined _MSC_VER && _MSC_VER<1300 // MSVC++7.1�汾��math.h֧��abs�����Ķ�������
inline float abs (float v) { return (float)fabs( v); }
inline double abs (double v) { return fabs( v); }
inline long double abs (long double v) { return fabsl( v); }
#endif

//#ifndef __MINMAX_DEFINED
//#  define max(a,b)    (((a) > (b)) ? (a) : (b))
//#  define min(a,b)    (((a) < (b)) ? (a) : (b))
//#endif

class ORBITDYN_API matrixException : public BaseException
{
public:
	matrixException(const std::string& details)
		:BaseException("matrix Exception Thrown: ",details)
	{
	}
	virtual ~matrixException()
	{
	}
	matrixException(const matrixException& me)
		:BaseException(me)
	{
	}
};

#define TEMPLATE 0

#if TEMPLATE
#define MAT_TEMPLATE template<typename type>
#define matrixT  matrix<type>
MAT_TEMPLATE class matrix;
typedef matrix<double> Matrix;
typedef matrix<double> cosmatrix;
#else
#define MAT_TEMPLATE 
#define matrixT  matrix
#define matrixtype double
class matrix;
typedef matrix Matrix;
typedef matrix cosmatrix;
#endif

MAT_TEMPLATE
class ORBITDYN_API matrix
{
public:
	// Constructors
	matrix(const matrixT& m);
	matrix(size_t row = 3, size_t col = 3);
	//matrix(size_t row, matrixtype* val);  һά����Ϊ��ʸ�� 
	matrix(size_t row, size_t col,matrixtype** val);
	matrix(size_t row, size_t col,matrixtype* val); // �������ʼ���������߱��뱣֤val�����㹻��������

	// Destructor
	~matrix();

	// Assignment operators
	matrixT& operator=(const matrixT& m);

	// Value extraction method
	size_t RowNo() const { return _m->Row; }
	size_t ColNo() const { return _m->Col; }

	// Subscript operator
	matrixtype& operator()(size_t row, size_t col);
	matrixtype  operator()(size_t row, size_t col) const;

	// Unary operators
	matrixT operator+();
	matrixT operator-();

	// Combined assignment - calculation operators
	matrixT& operator+=(const matrixT& m);
	matrixT& operator-=(const matrixT& m);
	matrixT& operator*=(const matrixT& m);
	matrixT& operator*=(const matrixtype& c);
	matrixT& operator/=(const matrixtype& c);
	matrixT& operator^=(const size_t& pow);

	// Miscellaneous -methods
	void Null(const size_t& row, const size_t& col);
	void Null();
	void Unit(const size_t& row);
	void Unit();
	void SetSize(size_t row, size_t col);
	void GetValue(matrixtype* val);

	// Utility methods
	matrixT Solve(const matrixT& v) const;
	matrixT Adj();
	matrixT Inv();
	double Det() const;
	double Norm();
	double Cofact(size_t row, size_t col);
	double Cond();

	// Type of matrices
	bool IsSquare();
	bool IsSingular();
	bool IsDiagonal();
	bool IsScalar();
	bool IsUnit();
	bool IsNull();
	bool IsSymmetric();
	bool IsSkewSymmetric();
	bool IsUpperTriangular();
	bool IsLowerTriangular();

protected:
	struct base_mat
	{
		matrixtype **Val;
		size_t Row, Col, RowSiz, ColSiz;
		int Refcnt;

		base_mat (size_t row, size_t col, matrixtype** v)
		{
			Row = row; RowSiz = row;
			Col = col; ColSiz = col;
			Refcnt = 1;

			Val = new matrixtype* [row];
			size_t rowlen = col * sizeof(matrixtype);

			for (size_t i=0; i < row; i++)
			{
				Val[i] = new matrixtype [col];
				if (v) memcpy( Val[i], v[i], rowlen);
				else memset( Val[i], 0, rowlen);
			}
		}
		~base_mat ()
		{
			for (size_t i=0; i < RowSiz; i++)
				delete [] Val[i];
			delete [] Val;
		}
	};
	base_mat *_m;

	void clone();
	void realloc(size_t row, size_t col);
	int pivot(size_t row);
};

class ORBITDYN_API InstallMatrix : public Matrix
{
public:
	InstallMatrix();
	~InstallMatrix();
};

// input stream function
MAT_TEMPLATE ORBITDYN_API std::istream& operator >> (std::istream& istrm, matrixT& m);

// output stream function
MAT_TEMPLATE ORBITDYN_API std::ostream& operator << (std::ostream& ostrm, const matrixT& m);

// logical equal-to operator
MAT_TEMPLATE ORBITDYN_API bool
operator == (const matrixT& m1, const matrixT& m2);

// logical no-equal-to operator
MAT_TEMPLATE ORBITDYN_API bool
operator != (const matrixT& m1, const matrixT& m2);

// binary addition operator
MAT_TEMPLATE ORBITDYN_API matrixT
operator + (const matrixT& m1, const matrixT& m2);

// binary subtraction operator
MAT_TEMPLATE ORBITDYN_API matrixT
operator - (const matrixT& m1, const matrixT& m2);

// binary scalar multiplication operator
MAT_TEMPLATE ORBITDYN_API matrixT
operator * (const matrixT& m, const matrixtype& no);


// binary scalar multiplication operator
MAT_TEMPLATE ORBITDYN_API matrixT
operator * (const matrixtype& no, const matrixT& m);

// binary matrix multiplication operator
MAT_TEMPLATE ORBITDYN_API matrixT
operator * (const matrixT& m1, const matrixT& m2);

// binary scalar division operator
MAT_TEMPLATE ORBITDYN_API matrixT
operator / (const matrixT& m, const matrixtype& no);

// binary scalar division operator
MAT_TEMPLATE ORBITDYN_API matrixT
operator / (const matrixtype& no, const matrixT& m);

// binary matrix division operator
MAT_TEMPLATE ORBITDYN_API matrixT
operator / (const matrixT& m1, const matrixT& m2);

// binary power operator
MAT_TEMPLATE ORBITDYN_API matrixT operator ^ (const matrixT& m, const size_t& pow);

// unary transpose operator
MAT_TEMPLATE ORBITDYN_API matrixT operator ~ (const matrixT& m);

// unary inversion operator
MAT_TEMPLATE ORBITDYN_API matrixT operator ! (const matrixT m);

/*!��X��ת��angle����ת����
[ 1          0         0     ]
[ 0    cos(angle)  sin(angle)]
[ 0   -sin(angle)  cos(angle)]
\param angle ת���Ľ�(����)
\return X��ת����
*/
ORBITDYN_API Matrix RotationX(double angle);

/*!��Y��ת��angle����ת����
[cos(angle)  0    -sin(angle)]
[     0      1         0     ]
[sin(angle)  0     cos(angle)]
\param angle ת���Ľ�(����)
\return Y��ת����
*/
ORBITDYN_API Matrix RotationY(double angle);

/*!��Z��ת��angle����ת����
[ cos(angle)  sin(angle)  0]
[-sin(angle)  cos(angle)  0]
[     0            0      1]
\param angle ת���Ľ�(����)
\return Z��ת����
*/
ORBITDYN_API Matrix RotationZ(double angle);

/*!����n*n��λ����
*/
ORBITDYN_API Matrix eye(size_t n);

#endif //__STD_MATRIX_H
