#ifndef __COORDINATION_H
#define __COORDINATION_H

#include "config.h"
#include "Vector.h"
#include <cstdio>

//! �ѿ���ֱ������
class ORBITDYN_API CCartesian
{
public:
	double x,y,z,dx,dy,dz;

	CCartesian(void):x(0),y(0),z(0),dx(0),dy(0),dz(0) {	}
	CCartesian(double d1,double d2,double d3,double d4,double d5,double d6)
		: x(d1), y(d2), z(d3), dx(d4), dy(d5), dz(d6) { }
		CCartesian(double * arg)
		{
			memcpy(&x,arg,sizeof(double)*6);
		}
		CCartesian(Vector r,Vector v){
			x=r.x; y=r.y; z=r.z; dx=v.x; dy=v.y; dz=v.z;
			}
		~CCartesian(void){ }
};

//! ������
class ORBITDYN_API CSpherical
{
public:
	double Longitude,Latitude,Altitude;
	CSpherical():Longitude(0),Latitude(0),Altitude(0){ }
	CSpherical(double lon,double lat,double alt): Longitude(lon),Latitude(lat),Altitude(alt) { }
	~CSpherical(){ }
};

enum Coordination { ECI, VVLH, VNC, ECF};

#endif // __COORDINATION_H
