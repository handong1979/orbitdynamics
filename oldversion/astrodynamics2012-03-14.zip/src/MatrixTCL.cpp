#include "matrixTCL.h"

#if _MSC_VER < 1400
#define max(a,b)    (((a) > (b)) ? (a) : (b))
#define min(a,b)    (((a) < (b)) ? (a) : (b))
#endif //_MSC_VER

// Constructors
MAT_TEMPLATE matrixT::matrix(const matrixT& m)
{
	_m = m._m;
	_m->Refcnt++;
}

MAT_TEMPLATE matrixT::matrix(size_t row /*= 3*/, size_t col /*= 3*/)
{
	_m = new base_mat( row, col, 0);
}

//MAT_TEMPLATE matrixT::matrix(size_t row, matrixtype* val)
//{
//	_m = new base_mat( row, 1, 0);
//	for (size_t i=0; i < row; i++)
//	{
//		_m->Val[i][0] = val[i];
//	}
//}

MAT_TEMPLATE matrixT::matrix(size_t row, size_t col,matrixtype** val)
{
	_m = new base_mat( row, col, val);
}

MAT_TEMPLATE matrixT::matrix(size_t row, size_t col,matrixtype* val)
{
	_m = new base_mat( row, col, 0);
	for(size_t i=0;i<row;i++)
	{
		for(size_t j=0;j<col;j++)
		{
			_m->Val[i][j] = *(val+i*col+j);
		}
	}
}

// Destructor
MAT_TEMPLATE matrixT::~matrix()
{
	if (--_m->Refcnt == 0) delete _m;
}

// Assignment operators
MAT_TEMPLATE matrixT& matrixT::operator = (const matrixT& m)
{
	m._m->Refcnt++;
	if (--_m->Refcnt == 0) delete _m;
	_m = m._m;
	return *this;
}

// Subscript operator
MAT_TEMPLATE matrixtype& matrixT::operator () (size_t row, size_t col)
{
	if (row >= _m->Row || col >= _m->Col)
		throw matrixException( "matrixT::operator(): Index out of range!");
	if (_m->Refcnt > 1) clone();
	return _m->Val[row][col];
}

MAT_TEMPLATE matrixtype matrixT::operator () (size_t row, size_t col) const
{
	if (row >= _m->Row || col >= _m->Col)
		throw matrixException( "matrixT::operator(): Index out of range!");
	return _m->Val[row][col];
}

// Unary operators
MAT_TEMPLATE matrixT matrixT::operator + ()
{
	return *this; 
}

MAT_TEMPLATE matrixT matrixT::operator - ()
{
	matrixT temp(_m->Row,_m->Col);

	for (size_t i=0; i < _m->Row; i++)
		for (size_t j=0; j < _m->Col; j++)
			temp._m->Val[i][j] = - _m->Val[i][j];

	return temp;
}

// Combined assignment - calculation operators
MAT_TEMPLATE matrixT& matrixT::operator += (const matrixT& m)
{
	if (_m->Row != m._m->Row || _m->Col != m._m->Col)
		throw matrixException( "matrixT::operator+= : Inconsistent matrix sizes in addition!");
	if (_m->Refcnt > 1) clone();
	for (size_t i=0; i < m._m->Row; i++)
		for (size_t j=0; j < m._m->Col; j++)
			_m->Val[i][j] += m._m->Val[i][j];
	return *this;
}

MAT_TEMPLATE matrixT& matrixT::operator -= (const matrixT& m)
{
	if (_m->Row != m._m->Row || _m->Col != m._m->Col)
		throw matrixException( "matrixT::operator-= : Inconsistent matrix sizes in subtraction!");
	if (_m->Refcnt > 1) clone();
	for (size_t i=0; i < m._m->Row; i++)
		for (size_t j=0; j < m._m->Col; j++)
			_m->Val[i][j] -= m._m->Val[i][j];
	return *this;
}

MAT_TEMPLATE matrixT& matrixT::operator *= (const matrixT& m)
{
	if (_m->Col != m._m->Row)
		throw matrixException( "matrixT::operator*= : Inconsistent matrix sizes in multiplication!");

	matrixT temp(_m->Row,m._m->Col);

	for (size_t i=0; i < _m->Row; i++)
		for (size_t j=0; j < m._m->Col; j++)
		{
			temp._m->Val[i][j] = matrixtype(0);
			for (size_t k=0; k < _m->Col; k++)
				temp._m->Val[i][j] += _m->Val[i][k] * m._m->Val[k][j];
		}
		*this = temp;

		return *this;
}

MAT_TEMPLATE matrixT& matrixT::operator *= (const matrixtype& c)
{
	if (_m->Refcnt > 1) clone();
	for (size_t i=0; i < _m->Row; i++)
		for (size_t j=0; j < _m->Col; j++)
			_m->Val[i][j] *= c;
	return *this;
}

MAT_TEMPLATE matrixT& matrixT::operator /= (const matrixtype& c)
{
	if (_m->Refcnt > 1) clone();
	for (size_t i=0; i < _m->Row; i++)
		for (size_t j=0; j < _m->Col; j++)
			_m->Val[i][j] /= c;

	return *this;
}

MAT_TEMPLATE matrixT& matrixT::operator ^= (const size_t& pow)
{
	matrixT temp(*this);

	for (size_t i=2; i <= pow; i++)
		*this = *this * temp;

	return *this;
}


// Miscellaneous -methods
MAT_TEMPLATE void matrixT::Null(const size_t& row, const size_t& col)
{
	if (row != _m->Row || col != _m->Col)
		realloc( row,col);

	if (_m->Refcnt > 1)
		clone();

	for (size_t i=0; i < _m->Row; i++)
		for (size_t j=0; j < _m->Col; j++)
			_m->Val[i][j] = matrixtype(0);
	return;
}

MAT_TEMPLATE void matrixT::Null()
{
	if (_m->Refcnt > 1) clone();
	for (size_t i=0; i < _m->Row; i++)
		for (size_t j=0; j < _m->Col; j++)
			_m->Val[i][j] = matrixtype(0);
	return;
}

MAT_TEMPLATE void matrixT::Unit(const size_t& row)
{
	if (row != _m->Row || row != _m->Col)
		realloc( row, row);

	if (_m->Refcnt > 1)
		clone();

	for (size_t i=0; i < _m->Row; i++)
		for (size_t j=0; j < _m->Col; j++)
			_m->Val[i][j] = i == j ? matrixtype(1) : matrixtype(0);
	return;
}

MAT_TEMPLATE void matrixT::Unit()
{
	if (_m->Refcnt > 1) clone();
	size_t row = min(_m->Row,_m->Col);
	_m->Row = _m->Col = row;

	for (size_t i=0; i < _m->Row; i++)
		for (size_t j=0; j < _m->Col; j++)
			_m->Val[i][j] = i == j ? matrixtype(1) : matrixtype(0);
	return;
}

MAT_TEMPLATE void matrixT::SetSize(size_t row, size_t col)
{
	size_t i,j;
	size_t oldRow = _m->Row;
	size_t oldCol = _m->Col;

	if (row != _m->RowSiz || col != _m->ColSiz)
		realloc( row, col);

	for (i=oldRow; i < row; i++)
		for (j=0; j < col; j++)
			_m->Val[i][j] = matrixtype(0);

	for (i=0; i < row; i++)
		for (j=oldCol; j < col; j++)
			_m->Val[i][j] = matrixtype(0);

	return;
}

MAT_TEMPLATE void matrixT::GetValue(matrixtype* val)
{
	if( _m->Col != 0 )
		throw matrixException("matrixT::GetValue(): Only column matrix can get value!");
	for( size_t i=0; i<_m->Row; i++ )
	{
		val[i] = _m->Val[i][0];
	}
};

// Utility methods
MAT_TEMPLATE matrixT matrixT::Solve(const matrixT& v) const
{
	size_t i,j,k;
	double a1;

	if (!(_m->Row == _m->Col && _m->Col == v._m->Row))
		throw matrixException( "matrixT::Solve():Inconsistent matrices!");

	matrixT temp(_m->Row,_m->Col+v._m->Col);
	for (i=0; i < _m->Row; i++)
	{
		for (j=0; j < _m->Col; j++)
			temp._m->Val[i][j] = _m->Val[i][j];
		for (k=0; k < v._m->Col; k++)
			temp._m->Val[i][_m->Col+k] = v._m->Val[i][k];
	}
	for (k=0; k < _m->Row; k++)
	{
		int indx = temp.pivot(k);
		if (indx == -1)
			throw matrixException( "matrixT::Solve(): Singular matrix!");

		a1 = temp._m->Val[k][k];
		for (j=k; j < temp._m->Col; j++)
			temp._m->Val[k][j] /= a1;

		for (i=k+1; i < _m->Row; i++)
		{
			a1 = temp._m->Val[i][k];
			for (j=k; j < temp._m->Col; j++)
				temp._m->Val[i][j] -= a1 * temp._m->Val[k][j];
		}
	}
	matrixT s(v._m->Row,v._m->Col);
	for (k=0; k < v._m->Col; k++)
		for (int m=int(_m->Row)-1; m >= 0; m--)
		{
			s._m->Val[m][k] = temp._m->Val[m][_m->Col+k];
			for (j=m+1; j < _m->Col; j++)
				s._m->Val[m][k] -= temp._m->Val[m][j] * s._m->Val[j][k];
		}
		return s;
}

MAT_TEMPLATE matrixT matrixT::Adj()
{
	if (_m->Row != _m->Col)
		throw matrixException( "matrixT::Adj(): Adjoin of a non-square matrix.");

	matrixT temp(_m->Row,_m->Col);

	for (size_t i=0; i < _m->Row; i++)
		for (size_t j=0; j < _m->Col; j++)
			temp._m->Val[j][i] = Cofact(i,j);
	return temp;
}

MAT_TEMPLATE matrixT matrixT::Inv()
{
	size_t i,j,k;
	double a1,a2,*rowptr;

	if (_m->Row != _m->Col)
		throw matrixException( "matrixT::operator!: Inversion of a non-square matrix");

	matrixT temp(_m->Row,_m->Col);
	if (_m->Refcnt > 1) clone();


	temp.Unit();
	for (k=0; k < _m->Row; k++)
	{
		int indx = pivot(k);
		if (indx == -1)
			throw matrixException( "matrixT::operator!: Inversion of a singular matrix");

		if (indx != 0)
		{
			rowptr = temp._m->Val[k];
			temp._m->Val[k] = temp._m->Val[indx];
			temp._m->Val[indx] = rowptr;
		}
		a1 = _m->Val[k][k];
		for (j=0; j < _m->Row; j++)
		{
			_m->Val[k][j] /= a1;
			temp._m->Val[k][j] /= a1;
		}
		for (i=0; i < _m->Row; i++)
			if (i != k)
			{
				a2 = _m->Val[i][k];
				for (j=0; j < _m->Row; j++)
				{
					_m->Val[i][j] -= a2 * _m->Val[k][j];
					temp._m->Val[i][j] -= a2 * temp._m->Val[k][j];
				}
			}
	}
	return temp;
}

MAT_TEMPLATE double matrixT::Det() const
{
	size_t i,j,k;
	double piv,detVal = double(1);

	if (_m->Row != _m->Col)
		throw matrixException( "matrixT::Det(): Determinant a non-square matrix!");

	matrixT temp(*this);
	if (temp._m->Refcnt > 1) temp.clone();

	for (k=0; k < _m->Row; k++)
	{
		int indx = temp.pivot(k);
		if (indx == -1)
			return 0;
		if (indx != 0)
			detVal = - detVal;
		detVal = detVal * temp._m->Val[k][k];
		for (i=k+1; i < _m->Row; i++)
		{
			piv = temp._m->Val[i][k] / temp._m->Val[k][k];
			for (j=k+1; j < _m->Row; j++)
				temp._m->Val[i][j] -= piv * temp._m->Val[k][j];
		}
	}
	return detVal;
}

MAT_TEMPLATE double matrixT::Norm()
{
	double retVal = double(0);

	for (size_t i=0; i < _m->Row; i++)
		for (size_t j=0; j < _m->Col; j++)
			retVal += _m->Val[i][j] * _m->Val[i][j];
	retVal = sqrt( retVal);

	return retVal;
}

MAT_TEMPLATE double matrixT::Cofact(size_t row, size_t col)
{
	size_t i,i1,j,j1;

	if (_m->Row != _m->Col)
		throw matrixException( "matrixT::Cofact(): Cofactor of a non-square matrix!");

	if (row > _m->Row || col > _m->Col)
		throw matrixException( "matrixT::Cofact(): Index out of range!");

	matrixT temp (_m->Row-1,_m->Col-1);

	for (i=i1=0; i < _m->Row; i++)
	{
		if (i == row)
			continue;
		for (j=j1=0; j < _m->Col; j++)
		{
			if (j == col)
				continue;
			temp._m->Val[i1][j1] = _m->Val[i][j];
			j1++;
		}
		i1++;
	}
	double  cof = temp.Det();
	if ((row+col)%2 == 1)
		cof = -cof;

	return cof;
}

MAT_TEMPLATE double matrixT::Cond()
{
	matrixT inv = ! (*this);
	return (Norm() * inv.Norm());
}

// Type of matrices
MAT_TEMPLATE bool matrixT::IsSquare()
{
	return (_m->Row == _m->Col);
}

MAT_TEMPLATE bool matrixT::IsSingular()
{
	if (_m->Row != _m->Col)
		return false;
	return (Det() == double(0));
}

MAT_TEMPLATE bool matrixT::IsDiagonal()
{
	if (_m->Row != _m->Col)
		return false;
	for (size_t i=0; i < _m->Row; i++)
		for (size_t j=0; j < _m->Col; j++)
			if (i != j && _m->Val[i][j] != double(0))
				return false;
	return true;
}

MAT_TEMPLATE bool matrixT::IsScalar()
{
	if (!IsDiagonal())
		return false;
	double v = _m->Val[0][0];
	for (size_t i=1; i < _m->Row; i++)
		if (_m->Val[i][i] != v)
			return false;
	return true;
}

MAT_TEMPLATE bool matrixT::IsUnit()
{
	if (IsScalar() && _m->Val[0][0] == double(1))
		return true;
	return false;
}

MAT_TEMPLATE bool matrixT::IsNull()
{
	for (size_t i=0; i < _m->Row; i++)
		for (size_t j=0; j < _m->Col; j++)
			if (_m->Val[i][j] != double(0))
				return false;
	return true;
}

MAT_TEMPLATE bool matrixT::IsSymmetric()
{
	if (_m->Row != _m->Col)
		return false;
	for (size_t i=0; i < _m->Row; i++)
		for (size_t j=0; j < _m->Col; j++)
			if (_m->Val[i][j] != _m->Val[j][i])
				return false;
	return true;
}

MAT_TEMPLATE bool matrixT::IsSkewSymmetric()
{
	if (_m->Row != _m->Col)
		return false;
	for (size_t i=0; i < _m->Row; i++)
		for (size_t j=0; j < _m->Col; j++)
			if (_m->Val[i][j] != -_m->Val[j][i])
				return false;
	return true;
}

MAT_TEMPLATE bool matrixT::IsUpperTriangular()
{
	if (_m->Row != _m->Col)
		return false;
	for (size_t i=1; i < _m->Row; i++)
		for (size_t j=0; j < i-1; j++)
			if (_m->Val[i][j] != matrixtype(0))
				return false;
	return true;
}

MAT_TEMPLATE bool matrixT::IsLowerTriangular()
{
	if (_m->Row != _m->Col)
		return false;

	for (size_t j=1; j < _m->Col; j++)
		for (size_t i=0; i < j-1; i++)
			if (_m->Val[i][j] != matrixtype(0))
				return false;

	return true;
}

MAT_TEMPLATE void matrixT::clone()
{
	_m->Refcnt--;
	_m = new base_mat( _m->Row, _m->Col, _m->Val);
}

MAT_TEMPLATE void matrixT::realloc(size_t row, size_t col)
{
	if (row == _m->RowSiz && col == _m->ColSiz)
	{
		_m->Row = _m->RowSiz;
		_m->Col = _m->ColSiz;
		return;
	}

	base_mat *m1 = new base_mat( row, col, NULL);
	size_t colSize = min(_m->Col,col) * sizeof(matrixtype);
	size_t minRow = min(_m->Row,row);

	for (size_t i=0; i < minRow; i++)
		memcpy( m1->Val[i], _m->Val[i], colSize);

	if (--_m->Refcnt == 0)
		delete _m;
	_m = m1;

	return;
}

MAT_TEMPLATE int matrixT::pivot(size_t row)
{
	//int k = int(row); //warning C4267: ��=�� : �ӡ�size_t��ת������int�������ܶ�ʧ����
	size_t k = row;
	double amax,temp;

	amax = -1;
	for (size_t i=row; i < _m->Row; i++)
		if ( (temp = abs( _m->Val[i][row])) > amax && temp != 0.0)
		{
			amax = temp;
			k = i;
		}
		if (_m->Val[k][row] == matrixtype(0))
			return -1;
		if (k != size_t(row))
		{
			double* rowptr = _m->Val[k];
			_m->Val[k] = _m->Val[row];
			_m->Val[row] = rowptr;
			return (int)k;
		}
		return 0;
}

// input stream function
MAT_TEMPLATE
std::istream& operator >> (std::istream& istrm, matrixT& m)
{
	for (size_t i=0; i < m.RowNo(); i++)
		for (size_t j=0; j < m.ColNo(); j++)
		{
			matrixtype x;
			istrm >> x;
			m(i,j) = x;
		}
		return istrm;
}

// output stream function
MAT_TEMPLATE
std::ostream& operator << (std::ostream& ostrm, const matrixT& m)
{
	if(m.ColNo()==1)
	{
		for (size_t i=0; i < m.RowNo(); i++)
		{
			//for (size_t j=0; j < m.ColNo(); j++)
			//{
			matrixtype x = m(i,0);
			ostrm << x << '\t';
			//}
		}
	}
	else{
		for (size_t i=0; i < m.RowNo(); i++)
		{
			for (size_t j=0; j < m.ColNo(); j++)
			{
				matrixtype x = m(i,j);
				ostrm << x << '\t';
			}
			ostrm << std::endl;
		}
	}
	return ostrm;
}


// logical equal-to operator
MAT_TEMPLATE
ORBITDYN_API bool operator == (const matrixT& m1, const matrixT& m2)
{
	if (m1.RowNo() != m2.RowNo() || m1.ColNo() != m2.ColNo())
		return false;

	for (size_t i=0; i < m1.RowNo(); i++)
		for (size_t j=0; j < m1.ColNo(); j++)
			if (m1(i,j) != m2(i,j))
				return false;

	return true;
}

// logical no-equal-to operator
MAT_TEMPLATE ORBITDYN_API bool operator != (const matrixT& m1, const matrixT& m2)
{
	return (m1 == m2) ? false : true;
}

// binary addition operator
MAT_TEMPLATE ORBITDYN_API matrixT operator + (const matrixT& m1, const matrixT& m2)
{
	matrixT temp = m1;
	temp += m2;
	return temp;
}

// binary subtraction operator
MAT_TEMPLATE ORBITDYN_API matrixT operator - (const matrixT& m1, const matrixT& m2)
{
	matrixT temp = m1;
	temp -= m2;
	return temp;
}

// binary scalar multiplication operator
MAT_TEMPLATE ORBITDYN_API matrixT operator * (const matrixT& m, const matrixtype& no)
{
	matrixT temp = m;
	temp *= no;
	return temp;
}


// binary scalar multiplication operator
MAT_TEMPLATE ORBITDYN_API matrixT operator * (const matrixtype& no, const matrixT& m)
{
	return (m * no);
}

// binary matrix multiplication operator
MAT_TEMPLATE ORBITDYN_API matrixT operator * (const matrixT& m1, const matrixT& m2)
{
	matrixT temp = m1;
	temp *= m2;
	return temp;
}

// binary scalar division operator
MAT_TEMPLATE ORBITDYN_API matrixT operator / (const matrixT& m, const matrixtype& no)
{
	return (m * (double(1) / no));
}


// binary scalar division operator
MAT_TEMPLATE ORBITDYN_API matrixT operator / (const matrixtype& no, const matrixT& m)
{
	return (!m * no);
}

// binary matrix division operator
MAT_TEMPLATE ORBITDYN_API matrixT operator / (const matrixT& m1, const matrixT& m2)
{
	return (m1 * !m2);
}

// binary power operator
MAT_TEMPLATE ORBITDYN_API matrixT operator ^ (const matrixT& m, const size_t& pow)
{
	matrixT temp = m;
	temp ^= pow;
	return temp;
}

// unary transpose operator
MAT_TEMPLATE ORBITDYN_API matrixT operator ~ (const matrixT& m)
{
	matrixT temp(m.ColNo(),m.RowNo());

	for (size_t i=0; i < m.RowNo(); i++)
		for (size_t j=0; j < m.ColNo(); j++)
		{
			double x = m(i,j);
			temp(j,i) = x;
		}
		return temp;
}

// unary inversion operator
MAT_TEMPLATE ORBITDYN_API matrixT operator ! (const matrixT m)
{
	matrixT temp = m;
	return temp.Inv();
}

/*!��X��ת��angle����ת����
[ 1          0         0     ]
[ 0    cos(angle)  sin(angle)]
[ 0   -sin(angle)  cos(angle)]
\param angle ת���Ľ�(����)
\return X��ת����
*/
ORBITDYN_API Matrix RotationX(double angle)
{
	Matrix m(3,3);
	m(0,0) = 1.0;
	m(1,1) = cos(angle);
	m(2,2) = m(1,1);
	m(1,2) = sin(angle);
	m(2,1) = -m(1,2);
	return m;
}
/*!��Y��ת��angle����ת����
[cos(angle)  0    -sin(angle)]
[     0      1         0     ]
[sin(angle)  0     cos(angle)]
\param angle ת���Ľ�(����)
\return Y��ת����
*/
ORBITDYN_API Matrix RotationY(double angle)
{
	Matrix m(3,3);
	m(0,0) = cos(angle);
	m(1,1) = 1.0;
	m(2,2) = m(0,0);
	m(0,2) = -sin(angle);
	m(2,0) = -m(0,2);
	return m;
}
/*!��Z��ת��angle����ת����
[ cos(angle)  sin(angle)  0]
[-sin(angle)  cos(angle)  0]
[     0            0      1]
\param angle ת���Ľ�(����)
\return Z��ת����
*/
ORBITDYN_API Matrix RotationZ(double angle)
{
	Matrix m(3,3);
	m(0,0) = cos(angle);
	m(1,1) = m(0,0);
	m(2,2) = 1.0;
	m(0,1) = sin(angle);
	m(1,0) = -m(0,1);
	return m;
}

/*!���ɵ�λ����
*/
ORBITDYN_API Matrix eye(size_t n)
{
	Matrix e(n,n);
	e.Unit();
	return e;
}

InstallMatrix::InstallMatrix()
{
	_m = new base_mat( 3, 3, 0);
}

InstallMatrix::~InstallMatrix()
{

}