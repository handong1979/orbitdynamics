#include "Quaternion.h"

CQuaternion::CQuaternion(const Vector& e,double phi)
{
	double me = e.Module();
	Vector ee;
	if(me!=0)
		ee = e/e.Module();
	else
		ee = e;
	double sphi = sin(phi/2.0);
	qx = ee.x * sphi;
	qy = ee.y * sphi;
	qz = ee.z * sphi;
	qs = cos(phi/2.0);
}

CQuaternion::CQuaternion(Matrix& c)
{
	if(c.RowNo()!=3 || c.ColNo()!=3) 
		throw CQuaternionException("CQuaternion(Matrix& c),Matrix c is not a 3*3 matrix!");
	double trc1 = c(0,0) + c(1,1) + c(2,2) + 1.0;
	if( trc1 >= 0.004 )
	{
		qs = sqrt(trc1)/2.0;
		qx = (c(1,2) - c(2,1))/4.0/qs;
		qy = (c(2,0) - c(0,2))/4.0/qs;
		qz = (c(0,1) - c(1,0))/4.0/qs;
	}
	else if( 1.0 - c(0,0) + c(1,1) - c(2,2) >= 0.004 )
	{
		qy = sqrt(1.0 - c(0,0) + c(1,1) - c(2,2)) / 2.0 * (c(2,0)-c(0,2)>=0?1:-1);
		qx = (c(1,0) + c(0,1))/4.0/qy;
		qz = (c(2,1) + c(1,2))/4.0/qy;
		qs = (c(2,0) - c(0,2))/4.0/qy;
	}
	else if( 1.0 + c(0,0) - c(1,1) - c(2,2) >= 0.004 )
	{
		qx = sqrt(1.0 + c(0,0) - c(1,1) - c(2,2)) / 2.0 * (c(1,2)-c(2,1)>=0?1:-1);
		qy = (c(1,0) + c(0,1))/4.0/qx;
		qz = (c(0,2) + c(2,0))/4.0/qx;
		qs = (c(1,2) - c(2,1))/4.0/qx;
	}
	else
	{
		qz = sqrt(1.0 - c(0,0) - c(1,1) + c(2,2)) / 2.0 * (c(0,1)-c(1,0)>=0?1:-1);
		qx = (c(0,2) + c(2,0))/4.0/qz;
		qy = (c(1,2) + c(2,1))/4.0/qz;
		qz = (c(0,1) - c(1,0))/4.0/qz;
	}
	Normalize();
}

double CQuaternion::Norm()const
{
	return sqrt(qx*qx+qy*qy+qz*qz+qs*qs);
}

void CQuaternion::Normalize()
{
	double nrm = Norm();
	if ( qs > 0 )
	{
		qx = qx/nrm;
		qy = qy/nrm;
		qz = qz/nrm;
		qs = qs/nrm;
	}
	else // qs<0
	{
		qx = -qx/nrm;
		qy = -qy/nrm;
		qz = -qz/nrm;
		qs = -qs/nrm;
	}
}

Matrix CQuaternion::C() const
{
	Matrix c(3,3);
	c(0,0) = 1.0 - 2.0*(qy*qy+qz*qz);
	c(0,1) = 2.0*(qx*qy+qz*qs);
	c(0,2) = 2.0*(qx*qz-qy*qs);
	c(1,0) = 2.0*(qx*qy-qz*qs);
	c(1,1) = 1.0 - 2.0*(qx*qx+qz*qz);
	c(1,2) = 2.0*(qy*qz+qx*qs);
	c(2,0) = 2.0*(qx*qz+qy*qs);
	c(2,1) = 2.0*(qy*qz-qx*qs);
	c(2,2) = 1.0 - 2.0*(qx*qx+qy*qy);
	return c;
}

Vector CQuaternion::v() const
{
	return Vector(qx,qy,qz);
}

//////////////////////////////////////////////////////////////////////////
// �ǳ�Ա����
const CQuaternion operator-(const CQuaternion &q)
{
	return CQuaternion(-q.qx,-q.qy,-q.qz,-q.qs);
}

const CQuaternion operator*(const CQuaternion& q1,const CQuaternion& q2)
{
	CQuaternion q(q2.qs*q1.qx + q2.qz*q1.qy - q2.qy*q1.qz + q2.qx*q1.qs,
		-q2.qz*q1.qx + q2.qs*q1.qy + q2.qx*q1.qz + q2.qy*q1.qs,
		q2.qy*q1.qx - q2.qx*q1.qy + q2.qs*q1.qz + q2.qz*q1.qs,
		-q2.qx*q1.qx - q2.qy*q1.qy - q2.qz*q1.qz + q2.qs*q1.qs);
	q.Normalize();
	return q;
}

const CQuaternion operator/(const CQuaternion& q2,const CQuaternion& q1)
{
	CQuaternion q(-q2.qs*q1.qx - q2.qz*q1.qy + q2.qy*q1.qz + q2.qx*q1.qs,
		q2.qz*q1.qx - q2.qs*q1.qy - q2.qx*q1.qz + q2.qy*q1.qs,
		-q2.qy*q1.qx + q2.qx*q1.qy - q2.qs*q1.qz + q2.qz*q1.qs,
		q2.qx*q1.qx + q2.qy*q1.qy + q2.qz*q1.qz + q2.qs*q1.qs);
	q.Normalize();
	return q;
}

const CQuaternion Qm(const CQuaternion& q1,const CQuaternion& q2)
{
	return q1*q2;
}

const CQuaternion Qim(const CQuaternion& q1,const CQuaternion& q2)
{
	return q2/q1;
}

const Vector operator*(const CQuaternion& q,const Vector& v)
{
	return Vector( (1.0 - 2.0*(q.qy*q.qy+q.qz*q.qz))*v.x + 2.0*(q.qx*q.qy+q.qz*q.qs)*v.y + 2.0*(q.qx*q.qz-q.qy*q.qs)*v.z,
		2.0*(q.qx*q.qy-q.qz*q.qs)*v.x + (1.0 - 2.0*(q.qx*q.qx+q.qz*q.qz))*v.y + 2.0*(q.qy*q.qz+q.qx*q.qs)*v.z,
		2.0*(q.qx*q.qz+q.qy*q.qs)*v.x + 2.0*(q.qy*q.qz-q.qx*q.qs)*v.y + (1.0 - 2.0*(q.qx*q.qx+q.qy*q.qy))*v.z);
}

ostream & operator<<(ostream & os, const CQuaternion& q)
{
	os<<q.qx<<"\t"<<q.qy<<"\t"<<q.qz<<"\t"<<q.qs;
	return os;
}

istream & operator>>(istream & is, CQuaternion& q)
{
	is>>q.qx>>q.qy>>q.qz>>q.qs;
	return is;
}
