#include "Euler.h"
#include "utility.h"
#include "constant.h"
using namespace Constant;


CEuler::CEuler():
	seq(312),phi(0.0),theta(0.0),psi(0.0)
{

}

CEuler::CEuler(const unsigned int s,double a,double b,double c)
{
	seq = s;
	phi = a;
	theta = b;
	psi = c;
}

CEuler::CEuler( double* angle)
{
	seq = 312;
	phi = angle[0];
	theta = angle[1];
	psi = angle[2];
}

CEuler::~CEuler()
{

}

void CEuler::SetValue(double a,double b,double c)
{
	phi = a;
	theta = b;
	psi = c;
}

//! ����ת��Ķ�������������
Matrix CEuler::ToMatrix()
{
	Matrix A;
	if ( seq == 312 )
	{
		A = RotationY(theta)*RotationX(phi)*RotationZ(psi);
	}
	//else if( seq == 321 )
	//{
	//	A = RotationX(phi)*RotationY(theta)*RotationZ(psi);
	//}
	//else if( seq== 121 )
	//{
	//	A = RotationX(psi)*RotationY(theta)*RotationX(phi);
	//}
	//else if( seq== 123 )
	//{

	//}
	//else if( seq== 131 )
	//{

	//}
	//else if( seq== 132 )
	//{

	//}
	//else if( seq== 212 )
	//{

	//}
	//else if( seq== 213 )
	//{

	//}
	//else if( seq== 231 )
	//{

	//}
	//else if( seq== 232 )
	//{

	//}
	//else if( seq== 313 )
	//{

	//}
	//else if( seq== 323 )
	//{

	//}
	else
	{
		throw CEulerException("EulerAngles.ToMatrix : Do NOT define such a sequence!");
	}
	return A;
}	

//! ����С�Ƕ��µ���̬����
Matrix CEuler::SmallAngleMatrix()
{
	Matrix m(3,3);
	m.Unit();
	m(0,1) = psi;
	m(0,2) = -theta;
	m(1,0) = -psi;
	m(1,2) = phi;
	m(2,0) = theta;
	m(2,1) = -phi;
	return m;
}

void CEuler::SetValueFromMatrix312( const Matrix& m )
{
	seq = 312;
	if( fabs(m(1,2)) > 1 )
		phi = asin(m(1,2)/fabs(m(1,2)));
	else
		phi = asin(m(1,2));

	if( m(2,2) == 0 )
	{
		theta = -sign(m(0,2))*PI/2;
	}
	else
	{
		theta = atan(-m(0,2)/m(2,2));
		if( m(2,2) < 0 )
		{	
			if( m(0,2) > 0 )
				theta = theta - PI;
			else
				theta = theta + PI;
		}
	
	}

	if( m(1,1) == 0 )
	{
		psi = -sign(m(1,0))*PI/2;
	}
	else
	{
		psi = atan(-m(1,0)/m(1,1));
		if( m(1,1) < 0 )
		{
			if( m(1,0) > 0 )
				psi = psi - PI;
			else
				psi = psi + PI;
		}
	}	
}

void CEuler::SetValueFromMatrix123( const Matrix& m )
{
	if( fabs(m(2,0))>=1.0 )
		theta = asin(m(2,0)/fabs(m(2,0)));
	else
		theta = asin(m(2,0));

	if( fabs(m(0,0)) < 1.0e-7 )
	{
		psi = -sign(m(1,0))*PI/2.0;
	}
	else
	{
		psi = atan(-m(1,0)/m(0,0));
		if( m(0,0) < 0 )
		{
			if(m(1,0)>0)
				psi += -PI;
			else
				psi += PI;
		}
	}

	if( fabs(m(2,2)) < 1.0e-7 )
	{
		phi = -sign(m(2,1))*PI/2.0;
	}
	else
	{
		phi = atan(-m(2,1)/m(2,2));
		if( m(2,2) < 0 )
		{
			if(m(2,1)>0)
				phi += -PI;
			else
				phi += PI;
		}
	}
}

void CEuler::SetValueFromMatrix231( const Matrix& m )
{
	if( fabs(m(0,1))>=1.0 )
		psi = asin(m(0,1)/fabs(m(0,1)));
	else
		psi = asin(m(0,1));

	if( fabs(m(1,1)) < 1.0e-7 )
	{
		phi = -sign(m(2,1))*PI/2.0;
	}
	else
	{
		phi = atan(-m(2,1)/m(1,1));
		if( m(1,1) < 0 )
		{
			if(m(2,1)>0)
				phi += -PI;
			else
				phi += PI;
		}
	}

	if( fabs(m(0,0)) < 1.0e-7 )
	{
		theta = -sign(m(0,2))*PI/2.0;
	}
	else
	{
		theta = atan(-m(0,2)/m(0,0));
		if(m(0,0)<0)
		{
			if(m(0,2)>0)
				theta += -PI;
			else
				theta += PI;
		}
	}
}

std::ostream & operator<<(std::ostream & os, const CEuler& euler)
{
	os<<euler.phi<<"\t"<<euler.theta<<"\t"<<euler.psi;
	return os;
}
