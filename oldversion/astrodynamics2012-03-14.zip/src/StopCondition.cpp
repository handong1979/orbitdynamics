
#include "StopCondition.h"
#include "Satellite.h"

CStopCondition::CStopCondition()
{

}

CStopCondition::~CStopCondition()
{

}
