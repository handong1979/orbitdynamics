#include "Vector.h"

VEC_TEMPLATE Vector& Vector::operator=(const Vector& v) // ��ֵ����
{
	if(&v!=this)//����Ƿ����Ҹ�ֵ
	{
		x=v.x;
		y=v.y;
		z=v.z;
	}
	return *this;
}

// VEC_TEMPLATE Vector& Vector::operator=(const matrix& m)  // ����ֵ
// {
// 	x=m(0,0);
// 	y=m(1,0);
// 	z=m(2,0);
// 	return *this;
// }

VEC_TEMPLATE Vector::operator Matrix () const                   // ת��Ϊ3��1����
{
	Matrix a(3,1);
	a(0,0)=x;
	a(1,0)=y;
	a(2,0)=z;
	return a;
}

// Subscript operator
VEC_TEMPLATE double Vector::operator()(size_t a) const
{
	if(a==0) return x;
	else if(a==1) return y;
	else if(a==2) return z;
	else throw TVectorException("TVector operator() :index is out of range");
}

VEC_TEMPLATE double& Vector::operator()(size_t a)
{
	if(a==0) return x;
	else if(a==1) return y;
	else if(a==2) return z;
	else throw TVectorException("TVector operator() :index is out of range");
}

VEC_TEMPLATE double Vector::operator[](size_t a) const
{
	if(a==0) return x;
	else if(a==1) return y;
	else if(a==2) return z;
	else throw TVectorException("TVector operator() :index is out of range");
}

VEC_TEMPLATE double& Vector::operator[](size_t a)
{
	if(a==0) return x;
	else if(a==1) return y;
	else if(a==2) return z;
	else throw TVectorException("TVector operator() :index is out of range");
}

VEC_TEMPLATE void Vector::SetValue(double n1,double n2,double n3)//���ó�Ա����
{
	x=n1;
	y=n2;
	z=n3;
}

VEC_TEMPLATE void Vector::SetValue(double * ptr)//�������ʼ��
{
	x=ptr[0];	y=ptr[1];	z=ptr[2];
}

VEC_TEMPLATE double Vector::Module() const//��ģ
{
	return sqrt(x*x+y*y+z*z);
}

VEC_TEMPLATE Vector Vector::RotationX(double angle) const//��������x����ת
{
	return Vector(x, y*cos(angle)+z*sin(angle), -y*sin(angle)+z*cos(angle));
}

VEC_TEMPLATE Vector Vector::RotationY(double angle) const//��������y����ת
{
	return Vector(x*cos(angle)-z*sin(angle), y ,x*sin(angle)+z*cos(angle));
}

VEC_TEMPLATE Vector Vector::RotationZ(double angle) const//��������z����ת
{
	return Vector(x*cos(angle)+y*sin(angle), -x*sin(angle)+y*cos(angle), z);
}

VEC_TEMPLATE double* Vector::ToArray(double * ptr) const //ת��Ϊ����
{
	ptr[0]=x;	ptr[1]=y;	ptr[2]=z;
	return ptr;
}

VEC_TEMPLATE void Vector::Unit()//��λ��
{
	double m=Module();
	if(m==0) throw TVectorException("TVector::Unit() : Vector's module is zero!");
	x=x/m;	y=y/m;	z=z/m;
}

const Matrix Vector::CrossMatrix()
{
	Matrix c;
	c(0,0) = c(1,1) = c(2,2) = 0;
	c(0,1) = -z;
	c(0,2) = y;
	c(1,0) = z;
	c(1,2) = -x;
	c(2,0) = -y;
	c(2,0) = x;
	return c;
}

void Vector::Zero()
{
	x=0.0;
	y=0.0;
	z=0.0;
}

VEC_TEMPLATE ORBITDYN_API double Dot(const Vector& v1,const Vector& v2)//���
{
	return v1.x*v2.x+v1.y*v2.y+v1.z*v2.z;
}

VEC_TEMPLATE ORBITDYN_API double VVAngle(const Vector& v1,const Vector& v2)//��ʸ���н�
{
	return acos( (v1.x*v2.x+v1.y*v2.y+v1.z*v2.z)/v1.Module()/v2.Module() );
}

VEC_TEMPLATE ORBITDYN_API Vector
Cross(const Vector &v1,const Vector& v2)//���
{
	return Vector(v1.y*v2.z-v1.z*v2.y, v1.z*v2.x-v1.x*v2.z, v1.x*v2.y-v1.y*v2.x);
}

//**********************
//�ǳ�Ա���������
//**********************
VEC_TEMPLATE ORBITDYN_API Vector
operator+(const Vector& v1,const Vector& v2) //ʸ�����
{
	return Vector(v1.x+v2.x, v1.y+v2.y, v1.z+v2.z);
}

VEC_TEMPLATE ORBITDYN_API Vector
operator+=(Vector & v1,const Vector & v2) //ʸ������
{
	v1.x+=v2.x; 	v1.y+=v2.y; 	v1.z+=v2.z;
	return v1;
}

VEC_TEMPLATE ORBITDYN_API Vector
operator-(const Vector& v1,const Vector& v2) //ʸ�����
{
	return Vector(v1.x-v2.x, v1.y-v2.y, v1.z-v2.z);
}

VEC_TEMPLATE ORBITDYN_API Vector
operator-=(Vector & v1,const Vector & v2) //ʸ����
{
	v1.x-=v2.x; 	v1.y-=v2.y; 	v1.z-=v2.z;
	return v1;
}

VEC_TEMPLATE ORBITDYN_API Vector
operator-(const Vector& v)//��ʸ��
{
	return Vector(-v.x,-v.y,-v.z);
}

MAT_TEMPLATE ORBITDYN_API Vector
operator*(const matrixT& m,const Vector& v)//3*3�����ʸ��
{
	if( m.RowNo()!=3 && m.ColNo()!=3)
		throw TVectorException("TVector operator* : Can't multiply with Non-3*3 Matrix!");
		
	return Vector(m(0,0)*v.x+m(0,1)*v.y+m(0,2)*v.z,
		m(1,0)*v.x+m(1,1)*v.y+m(1,2)*v.z,
		m(2,0)*v.x+m(2,1)*v.y+m(2,2)*v.z);
}

MAT_TEMPLATE ORBITDYN_API Vector
operator+(const matrixT& m,const Vector& v)//3*1�����ʸ��
{
	if( m.RowNo()!=3 && m.ColNo()!=1) 
		throw TVectorException("TVector operator+ : Can't plus with Non-3*1 Matrix!");
	return Vector(m(0,0)+v.x, m(1,0)+v.y, m(2,0)+v.z);
}

MAT_TEMPLATE ORBITDYN_API Vector
operator+(const Vector& v,const matrixT& m)//ʸ����3*1����
{
	if( m.RowNo()!=3 && m.ColNo()!=1) 
		throw TVectorException("TVector operator+ : Can't plus with Non-3*1 Matrix!");
	return Vector(m(0,0)+v.x, m(1,0)+v.y, m(2,0)+v.z);
}

MAT_TEMPLATE ORBITDYN_API Vector
operator-(const matrixT& m,const Vector& v)//3*1�����ʸ��
{
	if( m.RowNo()!=3 && m.ColNo()!=1) 
		throw TVectorException("TVector operator+ : Can't minus with Non-3*1 Matrix!");
	return Vector(m(0,0)-v.x, m(1,0)-v.y, m(2,0)-v.z);
}

MAT_TEMPLATE ORBITDYN_API Vector
operator-(const Vector& v,const matrixT& m)//ʸ����3*1����
{
	if( m.RowNo()!=3 && m.ColNo()!=1) 
		throw TVectorException("TVector operator+ : Can't minus with Non-3*1 Matrix!");
	return Vector(v.x-m(0,0), v.y-m(1,0), v.z-m(2,0));
}

#if defined _MSC_VER && _MSC_VER>1300
// in MSVC7.1 this can be compilered, but not in MSVC6.0

ORBITDYN_API Vector operator*(const Vector& v,const double num) //ʸ������
{
	return Vector(v.x*num, v.y*num, v.z*num);
}

ORBITDYN_API Vector operator*(const double num,const Vector& v) //����ʸ��
{
	return (v*num);
}

#else
// in MSVC6.0 

ORBITDYN_API Vector operator*(const Vector& v,const double num) //ʸ������
{
	return Vector(v.x*num, v.y*num, v.z*num);
}

ORBITDYN_API Vector operator*(const double num,const Vector& v) //����ʸ��
{
	return (v*num);
}
#endif

ORBITDYN_API double operator*(const Vector& v1,const Vector& v2)//���
{
	return Dot(v1,v2);
}

ORBITDYN_API Vector operator^(const Vector& v1,const Vector& v2)//���
{
	return Cross(v1,v2);
}

ORBITDYN_API Vector operator/(const Vector& v,const double num) //ʸ��������
{
	if(num==0) throw TVectorException("TVector operator/ : Divide by zero!");
	return Vector(v.x/num, v.y/num, v.z/num);
}

VEC_TEMPLATE std::ostream & operator<< (std::ostream & ostrm, const Vector& v)//�����
{
	ostrm<<v.x<<"\t"<<v.y<<"\t"<<v.z;
	return ostrm;
}
VEC_TEMPLATE std::istream & operator>> (std::istream & istrm,Vector& v)//������
{
	istrm>>v.x;
	istrm>>v.y;
	istrm>>v.z;
	return istrm;
}
