classdef ppparam
    %����������ƽ�����    
    
    properties
        thetaD = 0;
        thetaB = 0;
        Kx = 0;
        aJL = 0;
        dthetaL = 0;
        dthetaLL = 0;
        dthetaS = 0;
        dthetaV = 0;
    end
    
    methods
        % ���캯��
        function pp = ppparam(thetaD,thetaB,Kx,dthetaS,dthetaV,dthetaL,dthetaLL,aJL)
           if nargin > 0 % Support calling with 0 arguments
                pp.thetaD = thetaD;
                pp.thetaB = thetaB;
                pp.Kx = Kx;
                pp.aJL = aJL;
                pp.dthetaL = dthetaL;
                pp.dthetaLL = dthetaLL;
                pp.dthetaS = dthetaS;
                pp.dthetaV = dthetaV;
           end % nargin > 0 
        end % ppparam
    end

end

