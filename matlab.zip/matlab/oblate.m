% 常数:地球赤道平均半径
function y = oblate()
y = 0.003352813;