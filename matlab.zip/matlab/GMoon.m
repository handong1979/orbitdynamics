% 月球引力常数
%  See also Re,GEarth,Rm,GSun.
function y = GMoon()
y = 4902.800269;