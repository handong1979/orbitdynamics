% 地球引力常数
%  See also Re,Rm,GMoon,GSun.
function y = GEarth()
y = 398600.4418;