% 绕Z轴旋转矩阵
function R = rotationz(angle)
<<<<<<< HEAD
R = rotz(angle);
=======
R = rotz(angle);
>>>>>>> 943c4faedec0557bb03b6d917afd83996852ce2a
