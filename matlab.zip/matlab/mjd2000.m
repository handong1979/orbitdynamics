% J2000.0的简约儒略日
function y = mjd2000()
y = 51544.5;