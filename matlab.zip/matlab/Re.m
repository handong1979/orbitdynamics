% 地球赤道半径
%  See also Rm,GEarth,GMoon,GSun.
function y = Re()
y = 6378.137;