% 太阳引力常数
%  See also Re,GEarth,GMoon,Rm.
function y = GSun()
y = 1.32712440018e+11;