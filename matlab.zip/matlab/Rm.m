% 月球赤道半径
%  See also Re,GEarth,GMoon,GSun.
function y = Rm()
y = 1738.2;