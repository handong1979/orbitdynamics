% 绕Y轴旋转矩阵
function R = rotationy(angle)
<<<<<<< HEAD
R = roty(angle);
=======
R = roty(angle);
>>>>>>> 943c4faedec0557bb03b6d917afd83996852ce2a
